# Start-R
R Language Learning

# 簡介
這是曾怡薰在台灣大學 參加 郭耀仁老師的R語言新手村時製作的網頁。

# 作業
![R語言新手村之資料分析報告]<https://faytseng.github.io/StartR/hw_1223.html>
